#
# Copyright 2010-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#

from .client import client
from .Lambda import StreamingBody

__version__ = '1.3.0'
INTERFACE_VERSION = '1.1'
